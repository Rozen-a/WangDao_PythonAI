# 作者: 王道 龙哥
# 2025年12月26日15时54分23秒
# xxx@qq.com


a = 'hello'
b = 'world'
c = 'hello'
str_dict = {'hello': 0x12334234, 'world': 0x134928423}


def func():
    t1 = [1, 2, 3]
