# 作者: 王道 龙哥
# 2025年12月26日14时57分27秒
# xxx@qq.com


my_list = ['a', 'h', 'b', 'C', 'f']

my_list.sort(key=lambda char: char.lower())
print(my_list)
