# 作者: 王道 龙哥
# 2025年12月29日16时08分15秒
# xxx@qq.com
import datetime

# 获取当前时间

print(datetime.datetime.now())