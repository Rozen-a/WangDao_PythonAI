# 作者: 王道 龙哥
# 2025年12月29日16时03分20秒
# xxx@qq.com

#如果没有写all，是不可以用*的
from my_package import *

my_module1.say_hello1()
# my_module2.say_hello2()

