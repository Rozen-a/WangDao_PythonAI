# 作者: 王道 龙哥
# 2025年12月29日11时12分28秒
# xxx@qq.com

def func1(a):
    b = int(input('请输入一个数'))
    result = a / b
    print(f'result={result}')
    return result