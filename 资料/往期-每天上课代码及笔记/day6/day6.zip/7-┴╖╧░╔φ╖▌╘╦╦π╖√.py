# 作者: 王道 龙哥
# 2025年12月29日10时44分51秒
# xxx@qq.com


a = [1, 2, 3]
b = [1, 2, 3]
print(a == b)  # True
print(a is b)  # False

