# 作者: 王道 龙哥
# 2025年12月29日15时49分57秒
# xxx@qq.com


import my_package

my_package.my_module1.say_hello1()
my_package.my_module2.say_hello2()





