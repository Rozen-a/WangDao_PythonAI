# 作者: 王道 龙哥
# 2025年12月29日15时49分07秒
# xxx@qq.com
def say_hello2():
    print("my module2...say...")