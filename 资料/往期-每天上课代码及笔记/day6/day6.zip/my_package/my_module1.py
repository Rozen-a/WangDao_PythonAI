# 作者: 王道 龙哥
# 2025年12月29日15时49分01秒
# xxx@qq.com
def say_hello1():
    print("my module1...say...")