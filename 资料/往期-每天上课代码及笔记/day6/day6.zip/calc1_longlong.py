# 作者: 王道 龙哥
# 2025年12月29日14时42分34秒
# xxx@qq.com
# calc.py（一个简单的模块）
pi = 3.14159  # 模块变量


def add(a, b):  # 模块函数
    return a + b


class Calculator:  # 模块类
    def div(self, a, b):
        return a / b
