# 作者: 王道 龙哥
# 2025年12月29日14时44分13秒
# xxx@qq.com

import calc
import calc1_longlong as ca
from calc import Calculator as Calculator1
from calc1_longlong import Calculator

print(calc.add(1, 2))
print(ca.add(2, 3))

obj1 = Calculator1()
obj2 = Calculator()
