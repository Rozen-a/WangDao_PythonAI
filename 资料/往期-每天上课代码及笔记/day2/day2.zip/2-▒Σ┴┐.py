# 作者: 王道 龙哥
# 2025年12月24日14时08分21秒
# xxx@qq.com

# 一切皆对象
name = 'a'
age = 38
height = 170.5
print(name)
print(type(name))
print(type(age))
print(type(height))
is_male = True
print(type(is_male))
print('-' * 50)
num1 = 100
num2 = 200
num3 = num1 + num2
print(num3)
print('-' * 50)
print(f'is_male+num1={is_male+num1}')
print('-' * 50)
# 复数
k = complex(2, 3)
print(k.real, k.imag)
