# 作者: 王道 龙哥
# 2025年12月24日11时14分14秒
# xxx@qq.com

# 打印helloworld
print('hello world')
# print("我爱唱歌")
# print("我爱跳舞")
# print("我爱rap")
# print("我爱篮球")
