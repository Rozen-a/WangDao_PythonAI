# 作者: 王道 龙哥
# 2025年12月24日16时43分56秒
# xxx@qq.com

def use_if():
    score = int(input('请输入成绩：'))
    if score >= 60:
        print('小明及格了')


def use_if_else():
    score = int(input('请输入成绩：'))
    if score >= 60:
        print('小明及格了')
    else:
        print('小明没及格')


def use_if_elif():
    score = int(input('请输入成绩：'))
    if score >= 90:
        print('小明得A')
    elif score >= 70:
        print('小明得B')
    else:
        print('小明得C')


# use_if()
# use_if_else()
use_if_elif()
