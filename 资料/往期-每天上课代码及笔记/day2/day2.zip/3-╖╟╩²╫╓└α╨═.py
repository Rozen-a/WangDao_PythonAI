# 作者: 王道 龙哥
# 2025年12月24日14时30分49秒
# xxx@qq.com
my_list = [1, 2, 3]
print(my_list)
print(type(my_list))

my_tuple = ('abc', '123', 'zhangsan')
print(my_tuple)

my_dict = {'name': 'zhangsan', 'age': 20}
print(my_dict)

my_set = {4, 5, 6}
print(my_set)
