# 作者: 王道 龙哥
# 2025年12月24日14时49分53秒
# xxx@qq.com
import keyword

f = 1.23456789123456789  # 17位精度
print(f)

print(keyword.kwlist)

