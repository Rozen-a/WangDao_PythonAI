# 作者: 王道 龙哥
# 2025年12月24日14时35分17秒
# xxx@qq.com
# 整数可以表示到无穷
num = 123
print(num)

# 输出二进制、八进制、十六进制
print(bin(num))
print(oct(num))
print(hex(num))

# 1Byte=8 bit
# 1KB=1024 Byte

# 磁盘格式化以后1T的不到1024G
# 磁盘 1T=1000*1000*1000 Byte

# 100Mbps 带宽  只有 12.5M
